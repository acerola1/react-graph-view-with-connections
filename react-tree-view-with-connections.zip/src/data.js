export default {
  timestamp: "11/02/2019 22:00",
  name: "Colour",
  children: [
    {
      name: "Black",
      children: []
    },
    {
      name: "Blue",
      children: [
        {
          name: "Aquamarine",
          children: []
        },
        {
          name: "Cyan",
          children: []
        },
        {
          name: "Navy",
          children: []
        },
        {
          name: "Turquoise",
          children: []
        }
      ]
    },
    {
      name: "Green",
      children: []
    },
    {
      name: "Purple",
      children: [
        {
          name: "Indigo",
          children: []
        },
        {
          name: "Violet",
          children: []
        }
      ]
    },
    {
      name: "Red",
      children: [
        {
          name: "Crimson",
          children: []
        },
        {
          name: "Maroon",
          children: []
        },
        {
          name: "Scarlet",
          children: []
        }
      ]
    },
    {
      name: "White",
      children: []
    },
    {
      name: "Yellow",
      children: []
    }
  ]
};
