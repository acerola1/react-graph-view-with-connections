import React from "react";
import TreeContainer from "./Components/TreeContainer";

import "./styles.css";

export default function App() {
  return (
    <div className="App">
      <TreeContainer />
    </div>
  );
}
